import sys
from .main import main

sys.exit(main("lib2to3.fixes"))
